// output.tf
// This file defines the output values for the azurerm_windows_web_app module.